<?php
/*
  Plugin Name: Serial Number Validation
  Description: A plugin that allows users to enter a serial number and validate it against a remote database.
  Version: 1.0
  Author: John Doe
*/

// Create a new menu item in the admin panel
add_action( 'admin_menu', 'serial_number_validation_menu' );
function serial_number_validation_menu() {
  add_options_page( 'Serial Number Validation', 'Serial Number Validation', 'manage_options', 'serial-number-validation', 'serial_number_validation_options' );
}

// Create a new options page for the plugin
function serial_number_validation_options() {
  if ( !current_user_can( 'manage_options' ) )  {
    wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
  }

  // Check if the form has been submitted
  if (isset($_POST['submit'])) {
    // Get the serial number from the form
    $serial_number = $_POST['serial_number'];

    // Connect to the remote database
    $host = "hostname";
    $username = "username";
    $password = "password";
    $dbname = "database_name";
    $conn = mysqli_connect($host, $username, $password, $dbname);

    // Check if the serial number exists in the remote database
    $query = "SELECT * FROM licenses WHERE serial_number='$serial_number'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
      // Serial number is valid, display "License active" message
      echo '<div class="updated notice"><p>License active</p></div>';
    } else {
      // Serial number is not valid, display "License plan not activated" message
      echo '<div class="error notice"><p>License plan not activated</p></div>';
    }
  }

  // Display the form to enter the serial number
  echo '
  <div class="wrap">
    <h1>Serial Number Validation</h1>
    <form method="post" action="">
      <label for="serial_number">Serial Number:</label>
      <input type="text" id="serial_number" name="serial_number" required>
      <input type="submit" name="submit" value="Validate">
    </form>
  </div>
  ';
}